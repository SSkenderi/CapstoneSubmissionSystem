package Final;

public class VendingItem {

    private int costInCents;    // the cost of the product. Example: 75
    private String name;        // the name of the product. Example: Coke
    private String selection;  // the command for selecting the product. Example: A

    public VendingItem(int costInCents, String name, String selection) {
        this.costInCents = costInCents;
        this.name = name;
        this.selection = selection;
    }

    public int getCostInCents() {
        return costInCents;
    }

    public void setCostInCents(int costInCents) {
        this.costInCents = costInCents;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSelection() {
        return selection;
    }

    public void setSelection(String selection) {
        this.selection = selection;
    }

    @Override

    public String toString() {

        return "Selection: " + selection + " " + name + ": " + costInCents + " cents";

    }
}
