package Final;

import java.util.ArrayList;
import java.util.Scanner;

public class VendingMachine {

    private ArrayList<VendingItem> items;
    private int bank = 0;
    private int deposited = 0;
    Scanner myObj = new Scanner(System.in);


    public VendingMachine() {
        this.items = items;

    }



    public void stockMachine(int costInCents, String name, String selection) {
        VendingItem stockedBev = new VendingItem(75, "Coke", "A");
        VendingItem stockedBev2 = new VendingItem(125, "Dr.Pepper", "C");
        VendingItem stockedSnack = new VendingItem(50, "Doritos", "B");
        items.add(stockedBev);
        items.add(stockedSnack);
        items.add(stockedBev2);
    }


    public void deposit(){
        String amountDeposited = myObj.nextLine();
        if (amountDeposited.equalsIgnoreCase("Q")) {
            bank = bank + 25;
            deposited = deposited +25;
            System.out.println("The amount you have deposited is: "+ deposited);
        } else if (amountDeposited.equalsIgnoreCase("D")) {
            bank = bank + 10;
            deposited = deposited + 10;
            System.out.println("The amount you have deposited is: "+ deposited);
        }
    }

    public void returnChange(){

    }

    public void showSelections() {
        for (int i = 0; i < items.size(); i++) {
            System.out.println(items.get(i));
        }
    }

    public void showInstructions() {
        System.out.println("Select (q) to deposit a quarter, (d) to deposit a dime, (x) to quit, or select an item");
    }

    private VendingItem findSelection(String selection) {
        System.out.println("Select an item");
        selection = myObj.nextLine();

        if (selection.equalsIgnoreCase("A")) {
            items.get(0);
        } else if (selection.equalsIgnoreCase("B")) {
            items.get(1);
        } else if (selection.equalsIgnoreCase("C")) {
            items.get(2);
        }
        return null;
    }

    private void run() {
        showSelections();
        showInstructions();

    }

    static public void main(String args[]){
        VendingMachine workingMachine = new VendingMachine();
        workingMachine.run();
    }

}
