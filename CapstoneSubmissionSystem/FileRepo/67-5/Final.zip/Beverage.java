package Final;

public class Beverage extends VendingItem{

    private int fluidOunces;

    public Beverage(int costInCents, String name, String selection) {
        super(costInCents, name, selection);
    }


    public int getFluidOunces() {
        return fluidOunces;
    }

    public void setFluidOunces(int fluidOunces) {
        this.fluidOunces = fluidOunces;
    }


}
