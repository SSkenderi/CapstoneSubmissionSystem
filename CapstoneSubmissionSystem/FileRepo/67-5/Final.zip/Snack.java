package Final;

public class Snack extends VendingItem {

    private float weightInPounds;

    public Snack(int costInCents, String name, String selection) {
        super(costInCents, name, selection);
    }
}
